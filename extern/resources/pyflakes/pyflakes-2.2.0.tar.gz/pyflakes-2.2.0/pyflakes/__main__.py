from pyflakes.api import main

# python -m pyflakes
if __name__ == '__main__':
    main(prog='pyflakes')
