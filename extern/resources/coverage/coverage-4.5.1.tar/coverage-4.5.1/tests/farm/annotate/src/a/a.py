# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://bitbucket.org/ned/coveragepy/src/default/NOTICE.txt

def a(x):
    if x == 1:
        print("x is 1")
    else:
        print("x is not 1")
