"""
Another import tree, this time not for completion, but static analysis.
"""

from .a import *
