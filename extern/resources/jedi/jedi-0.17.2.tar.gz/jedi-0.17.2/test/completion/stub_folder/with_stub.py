in_with_stub_both = 5
in_with_stub_python = 8


def stub_function(x: float, y):
    """
    Python docstring
    """
    return 1
