#!/bin/sh

$1 $(echo ${CTEST_ARGS})
