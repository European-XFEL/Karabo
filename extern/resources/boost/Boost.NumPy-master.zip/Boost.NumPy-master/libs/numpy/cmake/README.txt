The cmake files, FindNumPy.cmake and FindPythonLibsNew.cmake, in this
folder came from the numexpr project at
http://code.google.com/p/numexpr.

The numexpr project was also a valuable resource in making many of the
cmake constructs used in the cmake lists files written for
Boost.NumPy. The boost-python-examples project at
https://github.com/TNG/boost-python-examples was another helpful
resource for understanding how to use cmake with boost.python.
