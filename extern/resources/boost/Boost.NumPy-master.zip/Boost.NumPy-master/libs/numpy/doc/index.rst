.. Boost.NumPy documentation master file, created by
   sphinx-quickstart on Thu Oct 27 09:04:58 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Boost.NumPy's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 2

   Tutorial <tutorial/index>
   Reference <reference/index>
   cmakeBuild.rst

