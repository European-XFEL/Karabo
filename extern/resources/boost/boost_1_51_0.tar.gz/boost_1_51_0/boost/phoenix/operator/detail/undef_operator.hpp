/*==============================================================================
    Copyright (c) 2010 Thomas Heller

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#undef BOOST_PHOENIX_UNARY_RULE
#undef BOOST_PHOENIX_UNARY_FUNCTIONAL
#undef BOOST_PHOENIX_BINARY_RULE
#undef BOOST_PHOENIX_BINARY_FUNCTIONAL
#undef BOOST_PHOENIX_UNARY_EXPRESSION
#undef BOOST_PHOENIX_BINARY_EXPRESSION
#undef BOOST_PHOENIX_GRAMMAR
#undef BOOST_PHOENIX_UNARY_OPERATORS
#undef BOOST_PHOENIX_BINARY_OPERATORS
#undef BOOST_PHOENIX_DEFINE_OPERATOR_HPP
