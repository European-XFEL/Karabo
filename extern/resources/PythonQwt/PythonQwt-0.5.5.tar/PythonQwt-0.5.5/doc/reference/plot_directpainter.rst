.. automodule:: qwt.plot_directpainter
   :members:
