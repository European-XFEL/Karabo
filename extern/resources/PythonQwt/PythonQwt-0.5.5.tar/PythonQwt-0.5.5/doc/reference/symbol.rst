.. automodule:: qwt.symbol
   :members:
