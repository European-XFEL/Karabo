.. automodule:: qwt.transform
   :members:
