.. automodule:: qwt.toqimage
   :members:
