.. automodule:: qwt.plot_layout
   :members:
