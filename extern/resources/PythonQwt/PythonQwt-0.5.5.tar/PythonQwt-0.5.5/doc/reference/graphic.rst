.. automodule:: qwt.graphic
   :members:
