.. automodule:: qwt.plot_series
   :members:
