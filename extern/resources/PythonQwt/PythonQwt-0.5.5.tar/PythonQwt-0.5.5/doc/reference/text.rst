Text
----

.. automodule:: qwt.text
   :members:
