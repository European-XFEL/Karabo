.. automodule:: qwt.interval
   :members:
