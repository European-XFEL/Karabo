Data demo
~~~~~~~~~

.. image:: /images/tests/DataDemo.png

.. literalinclude:: /../qwt/tests/DataDemo.py
   :start-after: SHOW
