Image plot demo
~~~~~~~~~~~~~~~

.. image:: /images/tests/ImagePlotDemo.png

.. literalinclude:: /../qwt/tests/ImagePlotDemo.py
   :start-after: SHOW
