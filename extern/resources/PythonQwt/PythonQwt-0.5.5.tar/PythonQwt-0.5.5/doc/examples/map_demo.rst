Map demo
~~~~~~~~

.. image:: /images/tests/MapDemo.png

.. literalinclude:: /../qwt/tests/MapDemo.py
   :start-after: SHOW
