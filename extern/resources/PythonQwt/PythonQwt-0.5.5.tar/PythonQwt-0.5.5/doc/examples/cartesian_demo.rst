Cartesian demo
~~~~~~~~~~~~~~

.. image:: /images/tests/CartesianDemo.png

.. literalinclude:: /../qwt/tests/CartesianDemo.py
   :start-after: SHOW
