Bode demo
~~~~~~~~~

.. image:: /images/tests/BodeDemo.png

.. literalinclude:: /../qwt/tests/BodeDemo.py
   :start-after: SHOW
