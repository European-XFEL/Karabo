Curve benchmark demo
~~~~~~~~~~~~~~~~~~~~

.. image:: /images/tests/CurveBenchmark.png

.. literalinclude:: /../qwt/tests/CurveBenchmark.py
   :start-after: SHOW
