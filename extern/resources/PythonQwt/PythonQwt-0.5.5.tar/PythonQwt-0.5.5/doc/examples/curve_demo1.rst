Curve demo 1
~~~~~~~~~~~~

.. image:: /images/tests/CurveDemo1.png

.. literalinclude:: /../qwt/tests/CurveDemo1.py
   :start-after: SHOW
