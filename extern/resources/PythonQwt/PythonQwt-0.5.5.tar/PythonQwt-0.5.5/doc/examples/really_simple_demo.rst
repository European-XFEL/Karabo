Really simple demo
~~~~~~~~~~~~~~~~~~

.. image:: /images/tests/ReallySimpleDemo.png

.. literalinclude:: /../qwt/tests/ReallySimpleDemo.py
   :start-after: SHOW
