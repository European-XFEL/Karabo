Error bar demo
~~~~~~~~~~~~~~

.. image:: /images/tests/ErrorBarDemo.png

.. literalinclude:: /../qwt/tests/ErrorBarDemo.py
   :start-after: SHOW
