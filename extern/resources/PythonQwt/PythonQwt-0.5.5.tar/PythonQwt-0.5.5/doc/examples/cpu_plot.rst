CPU plot demo
~~~~~~~~~~~~~

.. image:: /images/tests/CPUplot.png

.. literalinclude:: /../qwt/tests/CPUplot.py
   :start-after: SHOW
