Curve styles
~~~~~~~~~~~~

.. image:: /images/tests/CurveStyles.png

.. literalinclude:: /../qwt/tests/CurveStyles.py
   :start-after: SHOW
