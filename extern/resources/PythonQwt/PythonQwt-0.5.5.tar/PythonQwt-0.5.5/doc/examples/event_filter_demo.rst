Event filter demo
~~~~~~~~~~~~~~~~~

.. image:: /images/tests/EventFilterDemo.png

.. literalinclude:: /../qwt/tests/EventFilterDemo.py
   :start-after: SHOW
