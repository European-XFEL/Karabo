
Build docker image from root directory of the repository:

```
docker -f .dockers\windows-vs-32\Dockerfile .
```


