To compare nbconvert html output to the notebook's native html see https://gist.github.com/9241376.git.
