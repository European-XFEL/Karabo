API Reference
=============

.. automodule:: aio_pika
    :members:

.. autoclass:: aio_pika.patterns.base
    :members:

.. autoclass:: aio_pika.patterns.Master
    :members:

.. autoclass:: aio_pika.patterns.Worker
    :members:

.. autoclass:: aio_pika.patterns.RPC
    :members:
