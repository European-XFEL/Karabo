RabbitMQ tutorial
=================

.. toctree::
   :glob:
   :maxdepth: 3
   :caption: RabbitMQ tutorial adopted for aio-pika

   *-*
