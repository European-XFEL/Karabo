#------------------------------------------------------------------------------
# Copyright (c) 2005-2013 by Enthought, Inc.
# All rights reserved.
#------------------------------------------------------------------------------
""" Scripts and assert tools related to running unit tests.
 
These scripts also allow running test suites in separate processes and
aggregating the results.
"""
