#-----------------------------------------------------------------------------
#
#  Copyright (c) 2007 by Enthought, Inc.
#  All rights reserved.
#
#-----------------------------------------------------------------------------
""" Supports sharing settings across projects or programs on the same system.
    Part of the EnthoughtBase project.
"""
