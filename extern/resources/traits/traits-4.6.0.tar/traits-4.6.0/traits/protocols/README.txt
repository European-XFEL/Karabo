The traits.protocols package has been deprecated in Traits 4.4.0.

Please use the traits.adaptation package instead (see the "Migration guide"
in the Traits documentation).

