"""Trivial Interfaces and Adaptation from PyProtocols.

This package used to be a subset of the files from Phillip J. Eby's PyProtocols
package. The package has been substituted by :mod:`traits.adaptation` as of
Traits 4.4.0.

Currently, the package contains deprecated aliases for backward compatibility,
and will be removed in Traits 5.0 .

"""
