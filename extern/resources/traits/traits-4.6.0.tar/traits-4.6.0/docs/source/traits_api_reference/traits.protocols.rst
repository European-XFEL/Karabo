:mod:`protocols` Package
========================

.. note:: The :mod:`traits.protocols` package is deprecated.  Use the :mod:`traits.adaptation` package instead in new code.


.. automodule:: traits.protocols
    :members:
    :undoc-members:
    :show-inheritance:
