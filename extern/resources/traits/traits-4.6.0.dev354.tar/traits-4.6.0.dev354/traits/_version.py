# THIS FILE IS GENERATED FROM TRAITS SETUP.PY
version = '4.6.0'
full_version = '4.6.0.dev354'
git_revision = 'ac5d029'
is_released = False

if not is_released:
    version = full_version
