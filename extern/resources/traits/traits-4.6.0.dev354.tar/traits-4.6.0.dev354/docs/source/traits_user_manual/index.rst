Traits 4 User Manual
====================

.. toctree::
    :maxdepth: 3

    front.rst
    intro.rst
    defining.rst
    notification.rst
    deferring.rst
    custom.rst
    advanced.rst
    testing.rst
    debugging.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
