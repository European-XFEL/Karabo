:mod:`adaptation` Package
=========================

:mod:`adaptation` Package
-------------------------

.. automodule:: traits.adaptation
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`adaptation_error` Module
------------------------------

.. automodule:: traits.adaptation.adaptation_error
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`adaptation_manager` Module
--------------------------------

.. automodule:: traits.adaptation.adaptation_manager
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`adaptation_offer` Module
------------------------------

.. automodule:: traits.adaptation.adaptation_offer
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`adapter` Module
---------------------

.. automodule:: traits.adaptation.adapter
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`cached_adapter_factory` Module
------------------------------------

.. automodule:: traits.adaptation.cached_adapter_factory
    :members:
    :undoc-members:
    :show-inheritance:

