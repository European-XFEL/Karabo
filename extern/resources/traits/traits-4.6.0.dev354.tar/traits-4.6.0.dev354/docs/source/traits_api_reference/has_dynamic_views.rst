:mod:`has_dynamic_views` Module
===============================

.. automodule:: traits.has_dynamic_views
    :no-members:

Classes
-------

.. autoclass:: DynamicViewSubElement

.. autoclass:: DynamicView

.. autoclass:: HasDynamicViews
