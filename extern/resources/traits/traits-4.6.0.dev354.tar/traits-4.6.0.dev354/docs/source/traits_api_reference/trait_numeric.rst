:mod:`trait_numeric` Module
===========================

.. automodule:: traits.trait_numeric
    :no-members:

Classes
-------

.. autoclass:: AbstractArray

.. autoclass:: Array

.. autoclass:: ArrayOrNone

.. autoclass:: CArray

Function
--------

.. autofunction:: dtype2trait

