:mod:`etsconfig` Package
========================

:mod:`etsconfig` Package
------------------------

.. automodule:: traits.etsconfig
    :no-members:

:mod:`etsconfig` Module
-----------------------

.. automodule:: traits.etsconfig.etsconfig
    :no-members:

.. autodata:: ETSConfig
