:mod:`trait_value` Module
=========================

.. automodule:: traits.trait_value
    :no-members:

Classes
-------

.. autoclass:: BaseTraitValue

.. autoclass:: TraitValue

Functions
---------

.. autofunction:: SyncValue

.. autofunction:: TypeValue

.. autofunction:: DefaultValue