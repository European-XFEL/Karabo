.. automodule:: guiqwt


Contents:

.. toctree::
    :maxdepth: 2
    
    overview
    installation
    development
    examples
    sift
    disthelpers
    reference
    

Indices and tables:

* :ref:`genindex`
* :ref:`search`
