msgpack document
================

`MessagePack <http://msgpack.org>`_ is a efficient format for inter
language data exchange.

.. toctree::
   :maxdepth: 1

   api
