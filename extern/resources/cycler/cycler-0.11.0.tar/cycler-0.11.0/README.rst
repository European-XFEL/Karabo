|PyPi|_ |Supported Python versions|_ |Travis|_ |Codecov|_

.. |PyPi| image:: https://img.shields.io/pypi/v/cycler.svg?style=flat
.. _PyPi: https://pypi.python.org/pypi/cycler

.. |Supported Python versions| image:: https://img.shields.io/pypi/pyversions/cycler.svg
.. _Supported Python versions: https://pypi.python.org/pypi/cycler

.. |Travis| image:: https://travis-ci.org/matplotlib/cycler.svg?branch=master
.. _Travis: https://travis-ci.org/matplotlib/cycler

.. |Codecov| image:: https://codecov.io/github/matplotlib/cycler/badge.svg?branch=master&service=github
.. _Codecov: https://codecov.io/github/matplotlib/cycler?branch=master

cycler: composable cycles
=========================

Docs: https://matplotlib.org/cycler/
