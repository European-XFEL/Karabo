.. _uses:

Kiwisolver real uses
====================

The following sections describe how kiwisolver is used in third-party project,
and aim at providing more involved example of how kiwisolver can be used in
real life project.

.. toctree::
   :maxdepth: 2

   enaml.rst
