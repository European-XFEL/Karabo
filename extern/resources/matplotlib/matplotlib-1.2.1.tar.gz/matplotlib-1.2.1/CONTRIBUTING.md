Please refer to the [Coding
Guidelines](http://matplotlib.org/devel/coding_guide.html).
