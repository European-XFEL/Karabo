#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals

import pylab

pylab.plot([1, 2, 4])
pylab.title('Développés et fabriqués')
pylab.xlabel("réactivité nous permettent d'être sélectionnés et adoptés")
pylab.ylabel('André was here!')
pylab.text( 0.5, 2.5, 'Institut für Festkörperphysik', rotation=45)
pylab.text( 1, 1.5, 'AVA (check kerning)')

pylab.show()
