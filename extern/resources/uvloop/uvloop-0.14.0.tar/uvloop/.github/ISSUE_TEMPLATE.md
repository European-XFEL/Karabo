<!--
Thanks for wanting to report an issue you've found in uvloop. Please fill in
the template below.

It will be much easier for us to fix the issue if a test case that reproduces
the problem is provided, with clear instructions on how to run it.

Thank you!
-->

* **uvloop version**:
* **Python version**:
* **Platform**:
* **Can you reproduce the bug with `PYTHONASYNCIODEBUG` in env?**:
* **Does uvloop behave differently from vanilla asyncio? How?**:

<!-- Enter your issue details below this comment. -->
