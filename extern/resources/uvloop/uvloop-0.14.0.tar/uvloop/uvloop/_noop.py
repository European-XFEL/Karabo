def noop():
    """Empty function to invoke CPython ceval loop."""
    return
