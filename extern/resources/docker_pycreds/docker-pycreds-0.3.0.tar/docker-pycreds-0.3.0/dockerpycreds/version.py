version = "0.3.0"
version_info = tuple([int(d) for d in version.split("-")[0].split(".")])
