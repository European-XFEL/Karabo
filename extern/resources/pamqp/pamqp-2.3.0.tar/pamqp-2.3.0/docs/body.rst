pamqp.body
==========
.. automodule:: pamqp.body
    :members:
