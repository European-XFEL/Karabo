pamqp.header
============
.. automodule:: pamqp.header
    :members:
