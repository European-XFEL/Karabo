pamqp.decode
============
.. automodule:: pamqp.decode
    :members:
