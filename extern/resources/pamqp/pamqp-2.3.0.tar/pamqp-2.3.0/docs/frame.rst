pamqp.frame
===========
.. automodule:: pamqp.frame
    :members:
