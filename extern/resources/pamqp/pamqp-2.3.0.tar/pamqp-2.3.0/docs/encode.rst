pamqp.encode
============
.. automodule:: pamqp.encode
    :members:
