Installation
============

Installing nbclient
-------------------

From the command line:

.. code-block:: bash

   python3 -m pip install nbclient


.. seealso::

   `Installing Jupyter <https://jupyter.readthedocs.io/en/latest/install.html>`__
     NBClient is part of the Jupyter ecosystem.
