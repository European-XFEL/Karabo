nbclient.tests package
======================

Submodules
----------

nbclient.tests.base module
--------------------------

.. automodule:: nbclient.tests.base
   :members:
   :undoc-members:
   :show-inheritance:

nbclient.tests.fake\_kernelmanager module
-----------------------------------------

.. automodule:: nbclient.tests.fake_kernelmanager
   :members:
   :undoc-members:
   :show-inheritance:

nbclient.tests.test\_client module
----------------------------------

.. automodule:: nbclient.tests.test_client
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: nbclient.tests
   :members:
   :undoc-members:
   :show-inheritance:
