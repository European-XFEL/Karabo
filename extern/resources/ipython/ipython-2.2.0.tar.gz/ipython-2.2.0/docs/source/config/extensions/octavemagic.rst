.. _extensions_octavemagic:

===========
octavemagic
===========

.. note::

   The octavemagic extension has been moved to `oct2py <http://blink1073.github.io/oct2py/docs/>`_
   as :mod:`oct2py.ipython`.

.. automodule:: IPython.extensions.octavemagic
