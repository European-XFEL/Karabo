.. _about_index:

=============
About IPython
=============

.. toctree::
   :maxdepth: 1

   credits
   history
   license_and_copyright

