.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.error`
=========================
.. automodule:: IPython.core.error

.. currentmodule:: IPython.core.error

5 Classes
---------

.. autoclass:: IPythonCoreError
  :members:
  :show-inheritance:

.. autoclass:: TryNext
  :members:
  :show-inheritance:

.. autoclass:: UsageError
  :members:
  :show-inheritance:

.. autoclass:: StdinNotImplementedError
  :members:
  :show-inheritance:

.. autoclass:: InputRejected
  :members:
  :show-inheritance:
