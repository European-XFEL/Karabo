.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.payloadpage`
===============================
.. automodule:: IPython.core.payloadpage

.. currentmodule:: IPython.core.payloadpage

2 Functions
-----------

.. autofunction:: IPython.core.payloadpage.page


.. autofunction:: IPython.core.payloadpage.install_payload_page

