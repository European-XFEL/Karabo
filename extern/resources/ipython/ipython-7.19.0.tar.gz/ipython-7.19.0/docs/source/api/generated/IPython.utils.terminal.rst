.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.terminal`
=============================
.. automodule:: IPython.utils.terminal

.. currentmodule:: IPython.utils.terminal

5 Functions
-----------

.. autofunction:: IPython.utils.terminal.toggle_set_term_title


.. autofunction:: IPython.utils.terminal.set_term_title


.. autofunction:: IPython.utils.terminal.restore_term_title


.. autofunction:: IPython.utils.terminal.freeze_term_title


.. autofunction:: IPython.utils.terminal.get_terminal_size

