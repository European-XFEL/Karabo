.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.timing`
===========================
.. automodule:: IPython.utils.timing

.. currentmodule:: IPython.utils.timing

7 Functions
-----------

.. autofunction:: IPython.utils.timing.clocku


.. autofunction:: IPython.utils.timing.clocks


.. autofunction:: IPython.utils.timing.clock


.. autofunction:: IPython.utils.timing.clock2


.. autofunction:: IPython.utils.timing.timings_out


.. autofunction:: IPython.utils.timing.timings


.. autofunction:: IPython.utils.timing.timing

