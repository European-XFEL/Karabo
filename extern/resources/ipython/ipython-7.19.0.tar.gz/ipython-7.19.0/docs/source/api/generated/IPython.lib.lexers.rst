.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.lexers`
=========================
.. automodule:: IPython.lib.lexers

.. currentmodule:: IPython.lib.lexers

4 Classes
---------

.. autoclass:: IPythonPartialTracebackLexer
  :members:
  :show-inheritance:

.. autoclass:: IPythonTracebackLexer
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: IPythonConsoleLexer
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: IPyLexer
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.lib.lexers.build_ipy_lexer

