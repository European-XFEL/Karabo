.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.ultratb`
===========================
.. automodule:: IPython.core.ultratb

.. currentmodule:: IPython.core.ultratb

7 Classes
---------

.. autoclass:: TBTools
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ListTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: VerboseTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: FormattedTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: AutoFormattedTB
  :members:
  :show-inheritance:

.. autoclass:: ColorTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: SyntaxTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

10 Functions
------------

.. autofunction:: IPython.core.ultratb.inspect_error


.. autofunction:: IPython.core.ultratb.findsource


.. autofunction:: IPython.core.ultratb.getargs


.. autofunction:: IPython.core.ultratb.with_patch_inspect


.. autofunction:: IPython.core.ultratb.fix_frame_records_filenames


.. autofunction:: IPython.core.ultratb.is_recursion_error


.. autofunction:: IPython.core.ultratb.find_recursion


.. autofunction:: IPython.core.ultratb.text_repr


.. autofunction:: IPython.core.ultratb.eqrepr


.. autofunction:: IPython.core.ultratb.nullrepr

