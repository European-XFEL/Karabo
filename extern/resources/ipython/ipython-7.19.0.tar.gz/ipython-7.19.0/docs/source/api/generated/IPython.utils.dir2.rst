.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.dir2`
=========================
.. automodule:: IPython.utils.dir2

.. currentmodule:: IPython.utils.dir2

3 Functions
-----------

.. autofunction:: IPython.utils.dir2.safe_hasattr


.. autofunction:: IPython.utils.dir2.dir2


.. autofunction:: IPython.utils.dir2.get_real_method

