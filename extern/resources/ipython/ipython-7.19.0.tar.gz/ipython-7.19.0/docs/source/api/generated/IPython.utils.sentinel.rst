.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.sentinel`
=============================
.. automodule:: IPython.utils.sentinel

.. currentmodule:: IPython.utils.sentinel

1 Class
-------

.. autoclass:: Sentinel
  :members:
  :show-inheritance:

  .. automethod:: __init__
