.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.sysinfo`
============================
.. automodule:: IPython.utils.sysinfo

.. currentmodule:: IPython.utils.sysinfo

5 Functions
-----------

.. autofunction:: IPython.utils.sysinfo.pkg_commit_hash


.. autofunction:: IPython.utils.sysinfo.pkg_info


.. autofunction:: IPython.utils.sysinfo.get_sys_info


.. autofunction:: IPython.utils.sysinfo.sys_info


.. autofunction:: IPython.utils.sysinfo.num_cpus

