.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.page`
========================
.. automodule:: IPython.core.page

.. currentmodule:: IPython.core.page

9 Functions
-----------

.. autofunction:: IPython.core.page.display_page


.. autofunction:: IPython.core.page.as_hook


.. autofunction:: IPython.core.page.page_dumb


.. autofunction:: IPython.core.page.pager_page


.. autofunction:: IPython.core.page.page


.. autofunction:: IPython.core.page.page_file


.. autofunction:: IPython.core.page.get_pager_cmd


.. autofunction:: IPython.core.page.get_pager_start


.. autofunction:: IPython.core.page.page_more

