.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`testing.iptestcontroller`
=======================================
.. automodule:: IPython.testing.iptestcontroller

.. currentmodule:: IPython.testing.iptestcontroller

2 Classes
---------

.. autoclass:: TestController
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: PyTestController
  :members:
  :show-inheritance:

  .. automethod:: __init__

6 Functions
-----------

.. autofunction:: IPython.testing.iptestcontroller.prepare_controllers


.. autofunction:: IPython.testing.iptestcontroller.do_run


.. autofunction:: IPython.testing.iptestcontroller.report


.. autofunction:: IPython.testing.iptestcontroller.run_iptestall


.. autofunction:: IPython.testing.iptestcontroller.default_options


.. autofunction:: IPython.testing.iptestcontroller.main

