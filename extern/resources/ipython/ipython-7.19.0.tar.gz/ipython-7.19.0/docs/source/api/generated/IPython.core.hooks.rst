.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.hooks`
=========================
.. automodule:: IPython.core.hooks

.. currentmodule:: IPython.core.hooks

1 Class
-------

.. autoclass:: CommandChainDispatcher
  :members:
  :show-inheritance:

  .. automethod:: __init__

8 Functions
-----------

.. autofunction:: IPython.core.hooks.editor


.. autofunction:: IPython.core.hooks.synchronize_with_editor


.. autofunction:: IPython.core.hooks.shutdown_hook


.. autofunction:: IPython.core.hooks.late_startup_hook


.. autofunction:: IPython.core.hooks.show_in_pager


.. autofunction:: IPython.core.hooks.pre_prompt_hook


.. autofunction:: IPython.core.hooks.pre_run_code_hook


.. autofunction:: IPython.core.hooks.clipboard_get

