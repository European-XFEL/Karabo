.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`conftest`
=======================
.. automodule:: IPython.conftest

.. currentmodule:: IPython.conftest

5 Functions
-----------

.. autofunction:: IPython.conftest.get_ipython


.. autofunction:: IPython.conftest.work_path


.. autofunction:: IPython.conftest.nopage


.. autofunction:: IPython.conftest.xsys


.. autofunction:: IPython.conftest.inject

