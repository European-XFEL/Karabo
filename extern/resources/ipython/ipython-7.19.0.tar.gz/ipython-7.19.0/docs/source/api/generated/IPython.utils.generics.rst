.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.generics`
=============================
.. automodule:: IPython.utils.generics

.. currentmodule:: IPython.utils.generics

2 Functions
-----------

.. autofunction:: IPython.utils.generics.inspect_object


.. autofunction:: IPython.utils.generics.complete_object

