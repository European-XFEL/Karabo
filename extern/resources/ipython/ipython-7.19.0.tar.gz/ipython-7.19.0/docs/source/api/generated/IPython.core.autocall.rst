.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.autocall`
============================
.. automodule:: IPython.core.autocall

.. currentmodule:: IPython.core.autocall

3 Classes
---------

.. autoclass:: IPyAutocall
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ExitAutocall
  :members:
  :show-inheritance:

.. autoclass:: ZMQExitAutocall
  :members:
  :show-inheritance:
