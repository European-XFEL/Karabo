.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`testing.ipunittest`
=================================
.. automodule:: IPython.testing.ipunittest

.. currentmodule:: IPython.testing.ipunittest

2 Classes
---------

.. autoclass:: IPython2PythonConverter
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: Doc2UnitTester
  :members:
  :show-inheritance:

  .. automethod:: __init__

2 Functions
-----------

.. autofunction:: IPython.testing.ipunittest.count_failures


.. autofunction:: IPython.testing.ipunittest.ipdocstring

