.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.interactiveshell`
====================================
.. automodule:: IPython.core.interactiveshell

.. currentmodule:: IPython.core.interactiveshell

7 Classes
---------

.. autoclass:: ProvisionalWarning
  :members:
  :show-inheritance:

.. autoclass:: SpaceInInput
  :members:
  :show-inheritance:

.. autoclass:: SeparateUnicode
  :members:
  :show-inheritance:

.. autoclass:: ExecutionInfo
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ExecutionResult
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: InteractiveShell
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: InteractiveShellABC
  :members:
  :show-inheritance:

3 Functions
-----------

.. autofunction:: IPython.core.interactiveshell.sphinxify


.. autofunction:: IPython.core.interactiveshell.removed_co_newlocals


.. autofunction:: IPython.core.interactiveshell.get_default_colors

