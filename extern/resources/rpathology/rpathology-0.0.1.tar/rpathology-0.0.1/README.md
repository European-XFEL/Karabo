# rpathology #

[Pathological](https://en.wiktionary.org/wiki/pathological) [Adj.]
```
(computer science) Having properties that cause unusually bad behaviour, especially regarding correctness or performance. 
```

This project aims to make manipulation of RPATHs a bit easier.