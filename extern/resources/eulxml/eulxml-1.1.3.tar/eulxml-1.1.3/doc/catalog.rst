:mod:`eulxml.catalog` - XML Catalogs for loading schemas
--------------------------------------------------------

.. automodule:: eulxml.catalog
    :members:
