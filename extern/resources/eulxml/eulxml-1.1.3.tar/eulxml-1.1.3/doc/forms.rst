:mod:`eulxml.forms` - Forms for XmlObjects
-------------------------------------------

.. automodule:: eulxml.forms

.. autoclass:: eulxml.forms.XmlObjectForm
    :members:

.. automethod:: eulxml.forms.xmlobjectform_factory

.. autoclass:: eulxml.forms.SubformField
    :members:
