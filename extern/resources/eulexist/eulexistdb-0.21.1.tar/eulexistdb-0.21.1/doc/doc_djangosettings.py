# This dummy django settings file is used by sphinx while loading
# eulexistdb django tie-ins to examine them for autodoc generation.

SECRET_KEY = 'qua]f2v+[c_XKfiieb8j;7pz]aW?oWqfmq4/#1jXRXRiXUItCP'

