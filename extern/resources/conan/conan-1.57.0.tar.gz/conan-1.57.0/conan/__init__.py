from conans.model.conan_file import ConanFile
from conan.tools.scm import Version
from conans import __version__


conan_version = Version(__version__)
