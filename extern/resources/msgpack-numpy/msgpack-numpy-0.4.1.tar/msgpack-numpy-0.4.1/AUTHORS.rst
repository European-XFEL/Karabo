.. -*- rst -*-

Authors
=======
This software was written and packaged by `Lev E. Givon <lev@columbia.edu>`_.

Special thanks are due to the following parties for their contributions:

- Colin Jermain - Python 3 support.
- John Tyree - support for numpy scalar booleans.
- Mehdi Sadeghi - bug reports.
- tvkpz - bug reports.
