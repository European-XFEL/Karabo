===================================
Frequently Asked/Answered Questions
===================================

Which version should I use? I see multiple active releases.
===========================================================

Please see :ref:`the installation docs <release-lines>` which have an explicit
section about this topic.
