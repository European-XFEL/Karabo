/*
 * $Id: testSample.cc 1944 2010-09-01 10:41:35Z heisenb $
 *
 * Author: <your.email@xfel.eu>
 *
 * Created on September,2010,11:29AM
 *
 * Copyright (C) European XFEL GmbH Hamburg. All rights reserved.
 */

#include <iostream>
#include <assert.h>

using namespace std;

int testSample(int argc, char** argv ) {
  
  assert(1 == 1); // OK
  // assert(1 == 2); // This will cause the test to fail
  
  cout << "This is a simple test " << endl;
  
  return 0;  
}
