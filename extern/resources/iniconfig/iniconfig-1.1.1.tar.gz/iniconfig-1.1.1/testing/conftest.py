
option_doctestglob = "README.txt"
