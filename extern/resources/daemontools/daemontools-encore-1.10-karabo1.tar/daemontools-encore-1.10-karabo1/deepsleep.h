#ifndef DEEPSLEEP_H
#define DEEPSLEEP_H

extern void deepsleep(unsigned int);

#endif
