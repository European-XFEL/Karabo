
.. _changelog:

Changelog history
=================================

.. include:: ../../CHANGELOG.rst
