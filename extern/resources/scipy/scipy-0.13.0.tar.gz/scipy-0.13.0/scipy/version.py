
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.13.0'
version = '0.13.0'
full_version = '0.13.0'
git_revision = '1cc8beed5362ed290f5a8ddf4e99db49b4de6286'
release = True

if not release:
    version = full_version
