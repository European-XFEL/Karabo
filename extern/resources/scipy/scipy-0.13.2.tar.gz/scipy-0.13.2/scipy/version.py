
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.13.2'
version = '0.13.2'
full_version = '0.13.2'
git_revision = 'f3ebcf8b4f1e559feb3e2db8aa2f2f433bcff0f3'
release = True

if not release:
    version = full_version
