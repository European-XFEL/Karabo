GradientLegend
==============

.. autoclass:: pyqtgraph.GradientLegend
    :members:

    .. automethod:: pyqtgraph.GradientLegend.__init__

