LabelItem
=========

.. autoclass:: pyqtgraph.LabelItem
    :members:

    .. automethod:: pyqtgraph.LabelItem.__init__

