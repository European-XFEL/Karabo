ColorButton
===========

.. autoclass:: pyqtgraph.ColorButton
    :members:

    .. automethod:: pyqtgraph.ColorButton.__init__

