CheckTable
==========

.. autoclass:: pyqtgraph.CheckTable
    :members:

    .. automethod:: pyqtgraph.CheckTable.__init__

