ConsoleWidget
=============

.. autoclass:: pyqtgraph.console.ConsoleWidget
    :members:
    