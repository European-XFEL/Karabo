flowchart.Flowchart
===================

.. autoclass:: pyqtgraph.flowchart.Flowchart
    :members:

    .. automethod:: pyqtgraph.flowchart.Flowchart.__init__

