# -*- coding: utf-8 -*-
from pygments.formatters import HtmlFormatter


class HtmlFormatterWrapper(HtmlFormatter):
    name = 'HtmlWrapper'
