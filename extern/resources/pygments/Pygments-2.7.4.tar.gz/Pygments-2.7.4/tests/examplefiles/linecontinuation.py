apple.filter(x, y)
apple.\
    filter(x, y)

1 \
    . \
    __str__

from os import path
from \
        os \
        import \
        path

import os.path as something

import \
        os.path \
        as \
        something

class \
 Spam:
    pass

class Spam: pass

class Spam(object):
    pass

class \
 Spam \
  (
   object
 ) \
 :
 pass


def \
 spam \
  ( \
  ) \
  : \
  pass


