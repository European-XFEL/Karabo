/*-----------------------------------------------------------------------------
| Copyright (c) 2014-2020, Nucleic
|
| Distributed under the terms of the BSD 3-Clause License.
|
| The full license is in the file LICENSE, distributed with this software.
|----------------------------------------------------------------------------*/
#pragma once

#include <Python.h>

#define CPPY_MAJOR_VERSION 1
#define CPPY_MINOR_VERSION 1
#define CPPY_PATCH_VERSION 0

#define CPPY_VERSION "1.1.0"
