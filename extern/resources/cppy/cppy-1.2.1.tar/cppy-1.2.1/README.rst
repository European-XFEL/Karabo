Cppy
====

.. image:: https://github.com/nucleic/cppy/actions/workflows/ci.yml/badge.svg
    :target: https://github.com/nucleic/cppy/actions/workflows/ci.yml

A small C++ header library which makes it easier to write Python extension
modules. The primary feature is a PyObject smart pointer which automatically
handles reference counting and provides convenience methods for performing
common object operations.
