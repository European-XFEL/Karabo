.. automodule:: guidata


Contents:

.. toctree::
    :maxdepth: 2
    :glob:
    
    overview
    installation
    development
    examples
    reference
    

Indices and tables:

* :ref:`genindex`
* :ref:`search`
