.. automodule:: guidata.qthelpers
   :members:
