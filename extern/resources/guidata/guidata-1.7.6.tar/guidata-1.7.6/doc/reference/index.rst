Reference
=========

guidata API:

.. toctree::
    :maxdepth: 2
    
    dataset
    qthelpers
    disthelpers
    configtools
    userconfig
    utils
