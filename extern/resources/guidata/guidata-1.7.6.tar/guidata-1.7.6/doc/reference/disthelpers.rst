.. automodule:: guidata.disthelpers
   :members:
