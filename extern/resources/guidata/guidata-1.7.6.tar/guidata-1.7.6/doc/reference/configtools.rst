.. automodule:: guidata.configtools
   :members:
