GUIData reference
=================

.. automodule:: guidata.dataset
   :members:
   :inherited-members:

.. automodule:: guidata.qthelpers
   :members:
   :inherited-members:

.. automodule:: guidata.disthelpers
   :members:
   :inherited-members:

.. automodule:: guidata.configtools
   :members:
   :inherited-members:

.. automodule:: guidata.userconfig
   :members:
   :inherited-members:

.. automodule:: guidata.utils
   :members:
   :inherited-members:
