#include <qwidget.h>

class MainWin : public QWidget 
{
public:
    MainWin();
};


