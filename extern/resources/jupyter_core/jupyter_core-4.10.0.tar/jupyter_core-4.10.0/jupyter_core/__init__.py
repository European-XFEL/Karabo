from .version import __version__, version_info  # noqa
