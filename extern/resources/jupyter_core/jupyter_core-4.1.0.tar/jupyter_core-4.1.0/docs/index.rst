jupyter_core |version|
======================

This documentation only describes the public API in the ``jupyter_core``
package. For overview information about using Jupyter, see the `main Jupyter
docs <http://jupyter.readthedocs.org/en/latest/>`__.

Contents:

.. toctree::
   :maxdepth: 2

   paths
   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

